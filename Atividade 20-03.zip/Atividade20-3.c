#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/* Faca um programa onde o cliente devera digitar dos numeros e exiba a media no final. */
	
	printf("Faca um programa onde o cliente devera digitar dos numeros e exiba a media no final: \n");
	
	int media, n1, n2;
	
	printf("Digite o primeiro numero: ");
	scanf("%d",&n1);
	
	printf("Digite o primeiro numero: ");
	scanf("%d",&n2);
	
	media = (n1+n2)/2;
	
	printf("A media dos numeros e: %d \n",media);
	
	
	/* Faca um programa que calcule a area do quadrado. */
	
	
	printf("Faca um programa que calcule a area do quadrado: \n");
	
	int area,N1;
	
	printf("Para ser um quadrado, os lados deverao ser iguais. Digite o valor de UM lado do quadrado: ");
	scanf("%d",&N1);
	
	area = N1*N1;
	
	printf("A area do quadrado e: %d \n",area);	
	
	/* Faca um programa que o usuario digite a idade e mostre o ano que ele nasceu. */
	
	printf("Faca um programa que o usuario digite a idade e mostre o ano que ele nasceu: \n");
	
	int ano,idade,dia,mes;
	
	printf("Digite quantos anos voce tem: ");
	scanf("%d",&idade);
	
	ano = 2023-idade;
	
	printf("Voce nasceu no ano de: %d \n",ano);
	
	return 0;
}

